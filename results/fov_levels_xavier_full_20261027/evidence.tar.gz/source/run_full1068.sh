#!/usr/bin/env bash
cd /home/yingtian/stereo-fov-full-20261027 || exit 1
export PATH=/home/yingtian/stereo-fov-20261027/toolchain/root/usr/local/cuda-11.4/bin:$PATH
python3 src/evaluate_levels.py --binary /home/yingtian/stereo-fov-20261027/pirate_bench_fast --manifest fov_full1068/manifest.txt --out full1068 --batch-size 32 --warmup 3 --repeats 5 --quality-runs 1 --timing both --fast-resample
rc=$?
echo "$rc" > exit_code
exit "$rc"

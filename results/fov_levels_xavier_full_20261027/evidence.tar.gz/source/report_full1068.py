import csv, json, tarfile, hashlib
from pathlib import Path
import numpy as np
root=Path('results/fov_levels_xavier_full_20261027')
assert (root/'COMPLETE').exists()
read=lambda n:list(csv.DictReader((root/n).open(newline='',encoding='utf-8')))
meta=json.loads((root/'metadata.json').read_text(encoding='utf-8'))
q=read('quality.csv'); t=read('timings.csv'); over=read('overview.csv'); summary=read('summary.csv')
expected={f'{work}_{f:04d}.pir' for work,last in [('driving_15_300',299),('driving_15_800',779),('driving_35_300',299),('driving_35_800',779)] for f in range(7,last+1,2)}
assert len(expected)==1068 and {r['frame'] for r in q}==expected
assert len(q)==1068*5*2*3*5 and len(t)==1068*5*2*3*5
qkeys={(r['frame'],r['level'],r['timing'],r['mode'],r['region']) for r in q}
tkeys={(r['frame'],r['level'],r['timing'],r['mode'],r['iteration']) for r in t}
assert len(qkeys)==len(q) and len(tkeys)==len(t)
assert {int(r['iteration']) for r in t}==set(range(5))
assert {int(r['run']) for r in q}=={0}
source=root/'source/evaluate_levels.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()==meta['runner_sha256']
assert hashlib.sha256((root/'source/pirate_bench.cu').read_bytes()).hexdigest()==meta['cuda_source_sha256']
levels=['80x46','160x90','320x180','480x270','640x360']
assert {r['frame'] for r in t} == expected
for level in levels:
    for timing in ['resident', 'stream']:
        for mode in ['full', 'half_base', 'fov']:
            qt = [r for r in q if (r['level'], r['timing'], r['mode']) == (level, timing, mode)]
            tt = [r for r in t if (r['level'], r['timing'], r['mode']) == (level, timing, mode)]
            assert {(r['frame'], r['region']) for r in qt} == {(f, reg) for f in expected for reg in ['whole', 'fixed_center', 'fixed_periphery', 'level_roi', 'level_periphery']}
            assert {(r['frame'], int(r['iteration'])) for r in tt} == {(f, it) for f in expected for it in range(5)}
def row(level, timing='resident',mode='fov'):
    return next(r for r in over if (r['level'],r['timing'],r['mode'])==(level,timing,mode))
text='''# 完整有效 Driving：Xavier FOV 质量与时间

日期：2026-10-27。Jetson AGX Xavier，15W Desktop mode 7，L4T R35.6.4，CUDA 11.4.315。未锁频。

## 覆盖范围与口径

这次覆盖当前代码四组 Driving forward 的全部有效右眼重建帧，共 **1068 帧**，不是抽样：

| 序列 | 帧数 | 帧 ID |
| --- | ---: | --- |
| 15 mm / 300 | 147 | 7–299 的全部奇数帧 |
| 15 mm / 800 | 387 | 7–779 的全部奇数帧 |
| 35 mm / 300 | 147 | 7–299 的全部奇数帧 |
| 35 mm / 800 | 387 | 7–779 的全部奇数帧 |

不包含 backward 场景、偶数帧交替重建，或原 800 帧脚本范围之外的 781–799。不能称为整个原始 Driving 数据集所有场景/所有帧的完整评估。

- 五档中心 ROI，外围固定为半分辨率重建；`--fast-resample` 开启。
- 每档每帧均执行 full / half_base / fov；resident / stream 各一轮；每帧预热 3 次、计时 5 次。
- 每档每模式每种计时有 5340 个计时样本；质量取最后一次计时的实际输出，每帧每配置一个样本。
- 32 帧一批，档位顺序按批次轮换，三种模式顺序按计时迭代轮换。输入和源码 SHA-256 已核验。
- 计时与质量计算、文件 I/O、分配分开；stream wall 另含输入上传和输出回传。没有网络/视频解码/显示计时。
- 使用与 64 帧实验相同的 CUDA 二进制；只修改 Python 分批与增量保存逻辑。两轮预热/重复次数不同。
- 总表按所有帧汇总，因此 800 帧组权重更大；旧 64 帧表每组等量抽样。跨轮不能忽略样本权重变化。

## 主结果

PSNR 差 = FOV 对 GT 的分数 − 同次 full 对 GT 的分数；负数代表下降。原公式保留 uint8 溢出行为。
双眼平均差是**推导值**：仅在左眼不变、按左右眼 dB 取平均时，等于右眼差的一半；不是另跑完整双眼所得，也不是耗时减半。

| ROI | resident p50 / p95 (ms) | 相对 full 加速 | stream p50 (ms) | 右眼 ΔPSNR，原公式 (dB) | 推导双眼平均 ΔPSNR (dB) |
| --- | ---: | ---: | ---: | ---: | ---: |
'''
for level in levels:
    r=row(level); s=row(level,'stream'); delta=float(r['legacy_delta_vs_full_db'])
    text+=f"| {level} | {float(r['wall_p50_ms']):.3f} / {float(r['wall_p95_ms']):.3f} | {float(r['speedup_vs_full']):.2f}× | {float(s['wall_p50_ms']):.3f} | {delta:+.4f} | {delta/2:+.4f} |\n"
text+='''
完整 full / half_base / fov 的绝对分数、p99 和 GPU 时间见 [overview.csv](overview.csv)。各序列结果见 [summary.csv](summary.csv)。

## 四组分别看原公式的右眼质量差

| 序列 | 80×46 | 160×90 | 320×180 | 480×270 | 640×360 |
| --- | ---: | ---: | ---: | ---: | ---: |
'''
for work in ['driving_15_300','driving_15_800','driving_35_300','driving_35_800']:
    vals=[]
    for level in levels:
        subset=[r for r in summary if r['workload']==work and r['level']==level and r['timing']=='resident' and r['region']=='whole']
        fov=next(r for r in subset if r['mode']=='fov'); full=next(r for r in subset if r['mode']=='full')
        vals.append(float(fov['mean_legacy_whole_psnr_db'])-float(full['mean_legacy_whole_psnr_db']))
    text+='| '+work+' | '+' | '.join(f'{v:+.4f}' for v in vals)+' |\n'
text+='''
## 补充标准 PSNR（与原公式分开）

标准指标采用 float64 差分、峰值 255，未修改原 PSNR。固定中心始终为 160×90；外围为其补集。

| ROI | 全图 ΔPSNR (dB) | 固定中心 ΔPSNR (dB) | 固定外围 ΔPSNR (dB) |
| --- | ---: | ---: | ---: |
'''
for level in levels:
    r=row(level)
    text+=f"| {level} | {float(r['whole_delta_db']):+.4f} | {float(r['fixed_center_delta_db']):+.4f} | {float(r['fixed_periphery_delta_db']):+.4f} |\n"
text+='''
![Quality and timing](quality_speed.svg)

## 解释边界

- 仍保留原 uint8 深度缓存及非原子竞争写入；当前结果不能保证逐像素复现，也不能保证 ROI 质量与 full 一致。扩大帧覆盖不会修复该问题。
- 每帧每配置仅一个质量输出，重复计时不是独立质量样本。均值/百分位数不是置信区间。
- PSNR 上升不等于主观质量提高；没有测 SSIM/LPIPS。原公式与标准公式的趋势可能不同。
- 加速针对当前 CUDA full 路径，包含之前的上采样实现优化；不能全部归因于缩小 FOV，也不代表与最优 full 实现相比的收益。
- 旧 [64 帧报告](../fov_levels_xavier_20261027/README.md) 和原始记录保留，没有覆盖。

## 原始证据与重跑

`evidence.tar.gz` 包含逐次时间、逐帧质量、原始 CSV/日志、输入/程序哈希、温度日志和源码快照；未压缩副本仍保存在本地和板上。
板上实验目录：`/home/yingtian/stereo-fov-full-20261027/`；输入目录为其中 `fov_full1068/`。
同一板上的二进制：`/home/yingtian/stereo-fov-20261027/pirate_bench_fast`。

```bash
python3 jetson_cuda/evaluate_levels.py \\
  --binary /home/yingtian/stereo-fov-20261027/pirate_bench_fast \\
  --manifest /home/yingtian/stereo-fov-full-20261027/fov_full1068/manifest.txt \\
  --out results/xavier/full1068_new --batch-size 32 --warmup 3 --repeats 5 \\
  --quality-runs 1 --timing both --fast-resample
python3 jetson_cuda/report_levels.py results/xavier/full1068_new --plot
```
'''
(root/'README.md').write_text(text,encoding='utf-8')
with tarfile.open(root/'evidence.tar.gz','w:gz') as ar:
    for n in ['raw','quality.csv','timings.csv','metadata.json','source','self_test.log','tegrastats.log','COMPLETE','driver.log']:
        if (root/n).exists(): ar.add(root/n,arcname=n)
sha=hashlib.sha256((root/'evidence.tar.gz').read_bytes()).hexdigest()
(root/'checksums.sha256').write_text(sha+'  evidence.tar.gz\n',encoding='utf-8')
(root/'coverage.json').write_text(json.dumps(dict(frames=1068,quality_rows=len(q),timing_rows=len(t),quality_keys_unique=True,timing_keys_unique=True,frames_exact=True),indent=2),encoding='utf-8')
print('VERIFIED complete full1068 coverage:',len(q),'quality rows,',len(t),'timing rows; archive',sha)

import numpy as np
import numba
from numba import jit
from numba import cuda
import cv2
import time
import timeit
from time import perf_counter
import torch
from torchmetrics.image.lpip import LearnedPerceptualImagePatchSimilarity

from skimage.metrics import structural_similarity as ssim

def calculate_psnr(image1, image2):
    mse = np.mean((image1 - image2) ** 2)
    if mse == 0:
        return float('inf')
    max_pixel_value = 255.0  # Assuming images are in the range [0, 255]
    psnr = 20 * np.log10(max_pixel_value / np.sqrt(mse))
    # return psnr
    # psnr = skimage.metrics.peak_signal_noise_ratio(image1, image2)
    return psnr

def calculate_psnr_hole(image1, image2, mask):
    count = 0
    sum = 0
    for i in range(540):
        for j in range(960):
            if mask[i][j][0]:
                temp1 = (image1[i][j]-image2[i][j])**2
                # sum = sum+(temp1[0]+temp1[1]+temp1[2])/3
                sum = sum+np.average(temp1)
                # print(temp1)
                count = count+1
    if count == 0:
            return float('inf')
    mse = sum / count
    max_pixel_value = 255.0  # Assuming images are in the range [0, 255]
    psnr = 20 * np.log10(max_pixel_value / np.sqrt(mse))
    # return psnr
    # psnr = skimage.metrics.peak_signal_noise_ratio(image1, image2)
    return psnr
lpips = LearnedPerceptualImagePatchSimilarity(net_type='squeeze').to("cuda:0")
def compute_lpips(image1, image2):
    # image1=image1.to("cuda")
    # image2 = image2.to("cuda")
    reshaped_image1 = image1.transpose(2, 0, 1).reshape(1, 3, 540, 960)

    # Normalize the pixel values to the range [-1, 1]
    normalized_image1 = (reshaped_image1.astype(np.float32) / 127.5) - 1.0
    reshaped_image2 = image2.transpose(2, 0, 1).reshape(1, 3, 540, 960)

    # Normalize the pixel values to the range [-1, 1]
    normalized_image2 = (reshaped_image2.astype(np.float32) / 127.5) - 1.0
    normalized_image1=torch.tensor(normalized_image1)
    normalized_image2=torch.tensor(normalized_image2)
    normalized_image1=normalized_image1.to("cuda:0")
    normalized_image2=normalized_image2.to("cuda:0")
    lpips_result = lpips(normalized_image1, normalized_image2)
    lpips_result=lpips_result.to("cpu")
    return lpips_result.item()

def calculate_ssim(image1, image2):
    # Compute SSIM for each channel
    ssim_r = ssim(image1[:, :, 0], image2[:, :, 0])
    ssim_g = ssim(image1[:, :, 1], image2[:, :, 1])
    ssim_b = ssim(image1[:, :, 2], image2[:, :, 2])

    # Calculate overall SSIM (weighted average)
    wr, wg, wb = 1/3, 1/3, 1/3
    ssim_rgb = wr * ssim_r + wg * ssim_g + wb * ssim_b
    return ssim_rgb

def yuv_psnr(image1, image2):
    image1_yuv = cv2.cvtColor(image1, cv2.COLOR_BGR2YUV)
    image2_yuv = cv2.cvtColor(image2, cv2.COLOR_BGR2YUV)

    # If you want to access the Y, U, and V channels separately:
    Y1, U1, V1 = cv2.split(image1_yuv)
    Y2, U2, V2 = cv2.split(image2_yuv)

    # Calculate PSNR between the two Y channels in the YUV images
    psnr_yuv = cv2.PSNR(Y1, Y2)
    return psnr_yuv

@cuda.jit
def prev_to_now(right, max_uv, min_uv,right_prev, flow):
    # for i in range(10000):
        row, col = cuda.grid(2)
        # print(row,col)
        h, w, c = right.shape
        if (row>=h) or (row<0) or (col>=w) or (col<0):
            return

        u,v = flow[row][col]
        
        
        u = round(float(u)/65535*(max_uv[0]-min_uv[0])+min_uv[0])
        v = round(float(v)/65535*(max_uv[1]-min_uv[1])+min_uv[1])
        # u = round(float(u)/255*(max_uv[0]-min_uv[0])+min_uv[0])
        # v = round(float(v)/255*(max_uv[1]-min_uv[1])+min_uv[1])
        col_r = col +u
        row_r = row+v
        if (row_r>=h) or (row_r<0) or (col_r>=w) or (col_r<0):
            return
        temp = right_prev[row][col]
        
        right[row_r][col_r][0] = temp[0]
        right[row_r][col_r][1] = temp[1]
        right[row_r][col_r][2] = temp[2]
@cuda.jit
def now_to_prev(right, max_uv, min_uv,right_prev, flow):
    # for i in range(10000):
        row, col = cuda.grid(2)
        # print(row,col)
        h, w, c = right.shape
        if (row>=h) or (row<0) or (col>=w) or (col<0):
            return

        u,v = flow[row][col]
        u = round(float(u)/65535*(max_uv[0]-min_uv[0])+min_uv[0])
        v = round(float(v)/65535*(max_uv[1]-min_uv[1])+min_uv[1])
        # u = round(float(u)/255*(max_uv[0]-min_uv[0])+min_uv[0])
        # v = round(float(v)/255*(max_uv[1]-min_uv[1])+min_uv[1])
        # u=100
        # v=100
        col_r = col +u
        row_r = row+v
        if (row_r>=h) or (row_r<0) or (col_r>=w) or (col_r<0):
            return
        temp = right_prev[row_r][col_r]
        
        right[row][col][0] = temp[0]
        right[row][col][1] = temp[1]
        right[row][col][2] = temp[2]
@cuda.jit
def left_to_right(right1, max_d, left_img, depth, depth1):
    row, col = cuda.grid(2)
    h, w, c = left_img.shape
    if (row>=h) or (row<0) or (col>=w) or (col<0):
        return
    temp1 = depth[row][col]*max_d[0]
    temp1 = round(temp1 /65535)
    # temp1 = round(temp1 /255)
    col_r = col - temp1

    if col_r >= 0 and col_r <w and (depth1[row][col_r]==0 or depth1[row][col_r]<depth[row][col]):
        temp2 = left_img[row][col]
        right1[row][col_r][0] = temp2[0]
        right1[row][col_r][1] = temp2[1]
        right1[row][col_r][2] = temp2[2]
        temp3 = depth[row][col]
        depth1[row][col_r] = temp3

@cuda.jit
def right_to_left(right1, max_d, left_img, depth, depth1):
    row, col = cuda.grid(2)
    h, w, c = left_img.shape
    if (row>=h) or (row<0) or (col>=w) or (col<0):
        return
    temp1 = depth[row][col]*max_d[0]
    temp1 = round(temp1 /65535)
    # temp1 = round(temp1 /255)
    col_r = col + temp1

    if col_r >= 0 and col_r <w and (depth1[row][col_r]==0 or depth1[row][col_r]<depth[row][col]):
        temp2 = left_img[row][col]
        right1[row][col_r][0] = temp2[0]
        right1[row][col_r][1] = temp2[1]
        right1[row][col_r][2] = temp2[2]
        temp3 = depth[row][col]
        depth1[row][col_r] = temp3

@cuda.jit
def init(right, right1, right2, mask, mask1):
    row, col = cuda.grid(2)
    h, w, c = right.shape
    if (row>=h) or (row<0) or (col>=w) or (col<0):
        return
    for i in range(3):
        right[i][0] = 0
        right[i][1] = 0
        right[i][2] = 0
        right1[i][0] = 0
        right1[i][1] = 0
        right1[i][2] = 0
        right2[i][0] = 0
        right2[i][1] = 0
        right2[i][2] = 0
        mask[i] = 0
        mask1[i][0] = 0
        mask1[i][1] = 0
        mask1[i][2] = 0
    
@cuda.jit
def composite(right, right1, mask, mask1):
    row, col = cuda.grid(2)
    h, w, c = right.shape
    if (row>=h) or (row<0) or (col>=w) or (col<0):
        return
    temp1 = right1[row][col]
    agg2 = temp1[0]+temp1[1]+temp1[2]
    mask[row][col]=0
    mask1[row][col][0]=1
    mask1[row][col][1]=1
    mask1[row][col][2]=1
    if agg2==0:
        temp = right[row][col]
        agg1 = temp[0]+temp[1]+temp[2]
        if agg1 == 0:
            mask[row][col]=1
        right1[row][col][0] = temp[0]
        right1[row][col][1] = temp[1]
        right1[row][col][2] = temp[2]

@cuda.jit
def interpolate(right1, right2, mask):
    row, col = cuda.grid(2)
    h, w, c = right1.shape
    if (row>=h) or (row<0) or (col>=w) or (col<0):
        return
    if mask[row][col]==0:
        temp = right1[row][col]
        right2[row][col][0]=temp[0]
        right2[row][col][1]=temp[1]
        right2[row][col][2]=temp[2]
        return
    temp0 = 0
    temp1 = 0
    temp2 = 0
    sum=0
    for i in range(7):
        for j in range(7):
            row1 = row+i-3
            col1 = col+j-3
            if (row1>=h) or (row1<0) or (col1>=w) or (col1<0):
                continue
            elif mask[row1][col1]==0:
            # else:
                tempp = right1[row1][col1]
                temp0 = temp0+tempp[0]
                temp1 = temp1+tempp[1]
                temp2 = temp2+tempp[2]
                sum = sum+1
    if sum!=0:
        right2[row][col][0]=round(temp0/sum)
        right2[row][col][1]=round(temp1/sum)
        right2[row][col][2]=round(temp2/sum)

filest = open("st_psnr_cuda.log","w")
def generate_right(i,flip):
    number =  f"{(i+1):04d}"
    number1 = f"{(i):04d}"
    # print(i+1)
    left_img = cv2.imread("./8_left/"+number+".png")
    right_img = cv2.imread("./right/"+number+".png")
    if flip == 0:
        right_prev = cv2.imread("./8_right/"+number1+".png")
    else:
        right_prev = cv2.imread("./cuda_right/"+number1+".png")
    right_10 = cv2.imread("./10_right/"+number+".png")
    left_10 = cv2.imread("./10_left/"+number+".png")
    left_raw = cv2.imread("./left/"+number+".png")


    depth = cv2.imread("./gray_depth/"+number+".png", cv2.IMREAD_UNCHANGED)
    depth = depth.astype(np.uint16)
    flow_map_u=cv2.imread("./gray_u_past/"+number+".png", cv2.IMREAD_UNCHANGED)
    flow_map_u = flow_map_u.astype(np.uint16)
    flow_map_v=cv2.imread("./gray_v_past/"+number+".png", cv2.IMREAD_UNCHANGED)
    flow_map_v = flow_map_v.astype(np.uint16)
    flow=np.stack((flow_map_u,flow_map_v),axis=2)

    right = np.zeros_like(left_img)
    right1 = np.zeros_like(left_img)
    h, w, c = left_img.shape
    max111 = np.load("max_array.npy")
    max_d = max111[i]
    max222 = np.load("max_uv_past.npy")
    max_uv = max222[i]
    min222 = np.load("min_uv_past.npy")
    min_uv = min222[i]

    depth1 = np.zeros([h,w])
    # max_d = np.uint8(max_d)

    right_device = cuda.to_device(right)
    shape1 = right_prev.shape
    # right_device = cuda.device_array(shape1, dtype = np.uint8)
    right_prev_device = cuda.to_device(right_prev)
    max_uv_device = cuda.to_device(max_uv)
    min_uv_device = cuda.to_device(min_uv)
    flow_device = cuda.to_device(flow)
    max_d1 = np.zeros(1)
    max_d1[0] = max_d
    max_d_device = cuda.to_device(max_d1)
    depth_device = cuda.to_device(depth)
    left_img_device = cuda.to_device(left_img)
    shape2 = depth.shape
    depth1_device = cuda.device_array(shape2, dtype = np.uint8)
    right1_device = cuda.device_array(shape1, dtype = np.uint8)
    right2_device = cuda.device_array(shape1, dtype = np.uint8)
    # depth1_device = cuda.device_array_like(depth)
    # right1_device = cuda.device_array_like(left_img)
    # right2_device = cuda.device_array_like(left_img)
    mask_device = cuda.device_array(shape2, dtype = np.uint8)
    mask1_device = cuda.device_array(shape1, dtype = np.uint8)
    # result_device = cuda.device_array_like(left_img)
    blockdim = (32,32)
    griddim = (540//blockdim[0]+1, 960//blockdim[1]+1)
    # aaa = timeit.repeat('prev_to_now[griddim, blockdim](right_device, max_uv_device, min_uv_device, right_prev_device, flow_device)', 
    #                     globals=globals(), number=100, repeat=10)
    # print(aaa)
    init[griddim, blockdim](right_device, right1_device, right2_device, mask_device,mask1_device)
    now_to_prev[griddim, blockdim](right_device, max_uv_device, min_uv_device, right_prev_device, flow_device)
    left_to_right[griddim, blockdim](right1_device, max_d_device, left_img_device, depth_device, depth1_device)
    
    holes = right1_device.copy_to_host()
    # cv2.imwrite("holes.png", holes)
    composite[griddim, blockdim](right_device, right1_device, mask_device,mask1_device)
    mask1 = mask1_device.copy_to_host()
    interpolate[griddim, blockdim](right1_device, right2_device, mask_device)
    numba.cuda.synchronize()

    right_st = right2_device.copy_to_host()
    # filest.write(str(i)+"avg:  rgb_psnr: "+ str((calculate_psnr(left_raw, left_10)+calculate_psnr(right_st, right_img))/2)
    #                 # +"   right_psnr: "+str((calculate_psnr_hole(right_st, right_img, mask1)))
    #                 +"   right_psnr: "+str((calculate_psnr(right_st, right_img)))
    #                 +"   avg_lpips: " +str(compute_lpips(left_raw, left_10)+compute_lpips(right_st, right_img))
    #                 +"avg: yuv_psnr: "+ str((yuv_psnr(left_raw, left_10)+yuv_psnr(right_st, right_img))/2)+"\n"
    #                 )
    cv2.imwrite("cuda_right/"+number+".png", right_st)

def generate_left(i, flip):
    number =  f"{(i+1):04d}"
    number1 = f"{(i):04d}"
    # print(i+1)


    left_img = cv2.imread("./10_right/"+number+".png")
    right_img = cv2.imread("./left/"+number+".png")
    if flip == 0:
        right_prev = cv2.imread("./10_left/"+number1+".png")
    else:
        right_prev = cv2.imread("./cuda_left/"+number1+".png")
    right_10 = cv2.imread("./10_left/"+number+".png")
    left_10 = cv2.imread("./10_right/"+number+".png")
    left_raw = cv2.imread("./right/"+number+".png")


    depth = cv2.imread("./7_depth_right/"+number+".png", cv2.IMREAD_UNCHANGED)
    depth = depth.astype(np.uint8)
    flow_map_u=cv2.imread("./gray_u_left_past/"+number+".png", cv2.IMREAD_UNCHANGED)
    flow_map_u = flow_map_u.astype(np.uint16)
    flow_map_v=cv2.imread("./gray_v_left_past/"+number+".png", cv2.IMREAD_UNCHANGED)
    flow_map_v = flow_map_v.astype(np.uint16)
    flow=np.stack((flow_map_u,flow_map_v),axis=2)

    right = np.zeros_like(left_img)
    right1 = np.zeros_like(left_img)
    h, w, c = left_img.shape
    max111 = np.load("max_array_right.npy")
    max_d = max111[i]
    max222 = np.load("max_uv_left_past.npy")
    max_uv = max222[i]
    min222 = np.load("min_uv_left_past.npy")
    min_uv = min222[i]

    depth1 = np.zeros([h,w])
    # max_d = np.uint8(max_d)

    right_device = cuda.to_device(right)
    shape1 = right_prev.shape
    # right_device = cuda.device_array(shape1, dtype = np.uint8)
    right_prev_device = cuda.to_device(right_prev)
    max_uv_device = cuda.to_device(max_uv)
    min_uv_device = cuda.to_device(min_uv)
    flow_device = cuda.to_device(flow)
    max_d1 = np.zeros(1)
    max_d1[0] = max_d
    max_d_device = cuda.to_device(max_d1)
    depth_device = cuda.to_device(depth)
    left_img_device = cuda.to_device(left_img)
    shape2 = depth.shape
    depth1_device = cuda.device_array(shape2, dtype = np.uint8)
    right1_device = cuda.device_array(shape1, dtype = np.uint8)
    right2_device = cuda.device_array(shape1, dtype = np.uint8)
    mask_device = cuda.device_array(shape2, dtype = np.uint8)
    mask1_device = cuda.device_array(shape1, dtype = np.uint8)
    blockdim = (4,4)
    griddim = (540//blockdim[0]+1, 960//blockdim[1]+1)
    init[griddim, blockdim](right_device, right1_device, right2_device, mask_device,mask1_device)
    now_to_prev[griddim, blockdim](right_device, max_uv_device, min_uv_device, right_prev_device, flow_device)
    right_to_left[griddim, blockdim](right1_device, max_d_device, left_img_device, depth_device, depth1_device)
    composite[griddim, blockdim](right_device, right1_device, mask_device,mask1_device)
    interpolate[griddim, blockdim](right1_device, right2_device, mask_device)
    result = right_device.copy_to_host()
    numba.cuda.synchronize()
    
    mask1 = mask1_device.copy_to_host()
    right_st = right2_device.copy_to_host()

    filest.write(str(i)+"avg:  rgb_psnr: "+ str((calculate_psnr(left_raw, left_10)+calculate_psnr(right_st, right_img))/2)
                    # +"   right_psnr: "+str((calculate_psnr_hole(right_st, right_img, mask1)))
                    +"   right_psnr: "+str((calculate_psnr(right_st, right_img)))
                    +"   avg_lpips: " +str(compute_lpips(left_raw, left_10)+compute_lpips(right_st, right_img))
                    +"avg: yuv_psnr: "+ str((yuv_psnr(left_raw, left_10)+yuv_psnr(right_st, right_img))/2)+"\n"
                    )
    cv2.imwrite("cuda_left/"+number+".png", right_st)


for i in range(5,300):
    if i%2 == 0:
        print(i)
        generate_right(i,0)
    # # elif i%4 == 1 or i%4 == 2:
    # #     generate_right(i,1)
    # else:
        # generate_left(i,0)
filest.close()
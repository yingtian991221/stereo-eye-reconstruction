"""Paired right-eye quality/timing sweep. Requires only NumPy and Pillow.

Each invocation retains its raw timing CSV and log. Quality uses the actual
last timed output (not a second reconstruction). Metric work and PNG/PPM I/O
are outside the CUDA program's timing interval. Never overwrites a run folder.
"""
import argparse
import csv
import hashlib
import json
import platform
import shutil
import struct
import subprocess
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from PIL import Image


def write_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def rectangle(w, h, rw, rh):
    mask = np.zeros((h, w), dtype=bool)
    x, y = w // 2 - rw // 2, h // 2 - rh // 2
    mask[y:y + rh, x:x + rw] = True
    return mask


def metrics(out, gt, mask):
    # Supplemental metric only: original CUDA legacyPSNR is unchanged.
    delta = out[mask].astype(np.float64) - gt[mask].astype(np.float64)
    mse = float(np.mean(delta * delta))
    psnr = float('inf') if mse == 0 else float(10 * np.log10(255.0 ** 2 / mse))
    return mse, psnr


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--levels', default='80x46,160x90,320x180,480x270,640x360')
    parser.add_argument('--timing', choices=['resident', 'stream', 'both'], default='both')
    parser.add_argument('--repeats', type=int, default=100)
    parser.add_argument('--warmup', type=int, default=10)
    parser.add_argument('--quality-runs', type=int, default=3,
                        help='Independent runs to expose nondeterministic output variation')
    parser.add_argument('--fixed-region', default='160x90')
    parser.add_argument('--keep-images', action='store_true')
    args = parser.parse_args()
    levels = [tuple(map(int, s.split('x'))) for s in args.levels.split(',')]
    fixed = tuple(map(int, args.fixed_region.split('x')))
    if any(len(v) != 2 or min(v) < 1 for v in levels + [fixed]):
        parser.error('regions must be positive WIDTHxHEIGHT')
    if len(set(levels)) != len(levels) or min(args.repeats, args.warmup, args.quality_runs) < 1:
        parser.error('levels must be unique; counts must be positive')
    binary = args.binary.resolve(strict=True)
    manifest = args.manifest.resolve(strict=True)
    packets = [(manifest.parent / s.strip()).resolve(strict=True)
               for s in manifest.read_text(encoding='utf-8-sig').splitlines() if s.strip()]
    if not packets or len(set(packets)) != len(packets):
        parser.error('manifest must contain unique frames')
    # Validate all inputs before starting any benchmark.
    packet_info = []
    for packet in packets:
        raw = packet.read_bytes()
        magic, w, h = struct.unpack_from('<8sII', raw)
        if magic != b'PIRFRM1\0' or len(raw) != 56 + 15 * w * h:
            raise ValueError('Invalid packet: ' + str(packet))
        if any(rw + 6 > w or rh + 6 > h for rw, rh in levels) or fixed[0] >= w or fixed[1] >= h:
            raise ValueError('Regions do not fit ' + str(packet))
        packet_info.append(dict(file=str(packet), sha256=hashlib.sha256(raw).hexdigest(), width=w, height=h))
    args.out.mkdir(parents=True, exist_ok=False)
    (args.out / 'raw').mkdir()
    meta = dict(created_utc=datetime.now(timezone.utc).isoformat(), platform=platform.platform(),
                binary=str(binary), binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                arguments={k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
                packets=packet_info, quality_scope='right eye vs GT; last timed output per independent run')
    for label, command in [('git', ['git', 'rev-parse', 'HEAD']),
                           ('power', ['nvpmodel', '-q']), ('clocks', ['jetson_clocks', '--show']),
                           ('cuda', ['nvcc', '--version']), ('gpu', ['nvidia-smi'])]:
        try:
            result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    universal_newlines=True, timeout=15)
            meta[label] = result.stdout
        except (OSError, subprocess.TimeoutExpired) as exc:
            meta[label] = str(exc)
    release = Path('/etc/nv_tegra_release')
    if release.exists():
        meta['l4t'] = release.read_text()
    (args.out / 'metadata.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
    telemetry = None
    telemetry_file = None
    quality, times = [], []
    try:
        if shutil.which('tegrastats'):
            telemetry_file = (args.out / 'tegrastats.log').open('w')
            telemetry = subprocess.Popen(['tegrastats', '--interval', '1000'],
                                         stdout=telemetry_file, stderr=subprocess.STDOUT)
        with (args.out / 'self_test.log').open('w') as log:
            subprocess.run([str(binary), '--self-test'], stdout=log, stderr=subprocess.STDOUT, check=True)
        timings = ['resident', 'stream'] if args.timing == 'both' else [args.timing]
        for fi, (packet, info) in enumerate(zip(packets, packet_info)):
            w, h = info['width'], info['height']
            gt = np.frombuffer(packet.read_bytes(), dtype=np.uint8, offset=56 + 12 * w * h).reshape(h, w, 3)[:, :, ::-1]
            workload = packet.stem.rsplit('_', 1)[0]
            for run in range(args.quality_runs):
                # Rotate level order between frames/runs to reduce systematic heat/order bias.
                order = (fi + run) % len(levels)
                for rw, rh in levels[order:] + levels[:order]:
                    level = '%dx%d' % (rw, rh)
                    roi = rectangle(w, h, rw, rh)
                    fixed_roi = rectangle(w, h, *fixed)
                    regions = dict(whole=np.ones((h, w), dtype=bool), fixed_center=fixed_roi,
                                   fixed_periphery=~fixed_roi, level_roi=roi, level_periphery=~roi)
                    for timing in timings:
                        tag = '%04d_%s_%s_r%d' % (fi, level, timing, run)
                        prefix = args.out / 'raw' / tag
                        timing_csv = Path(str(prefix) + '.csv')
                        cmd = [str(binary), '--input', str(packet), '--roi-width', str(rw), '--roi-height', str(rh),
                               '--warmup', str(args.warmup), '--repeats', str(args.repeats),
                               '--csv', str(timing_csv), '--dump-prefix', str(prefix)]
                        if timing == 'stream':
                            cmd.append('--stream')
                        with Path(str(prefix) + '.log').open('w') as log:
                            log.write(json.dumps(cmd) + '\n')
                            log.flush()
                            subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=True)
                        with timing_csv.open(newline='') as f:
                            rows = list(csv.DictReader(f))
                        images = {}
                        for mode in ('full', 'half_base', 'fov'):
                            image_path = Path(str(prefix) + '_0_' + mode + '.ppm')
                            with Image.open(image_path) as im:
                                images[mode] = np.array(im)
                        for mode in images:
                            selected = [r for r in rows if r['mode'] == mode]
                            base = dict(workload=workload, frame=packet.name, level=level,
                                        roi_area_fraction=rw * rh / float(w * h), timing=timing, run=run, mode=mode)
                            for r in selected:
                                times.append(dict(base, iteration=int(r['iteration']), wall_ms=float(r['wall_ms']),
                                                  gpu_timeline_ms=float(r['gpu_timeline_ms'])))
                            legacy = float(selected[0]['legacy_right_psnr_db'])
                            for region, mask in regions.items():
                                mse, psnr = metrics(images[mode], gt, mask)
                                _, full_psnr = metrics(images['full'], gt, mask)
                                quality.append(dict(base, region=region, pixels=int(mask.sum()), mse=mse,
                                                    standard_psnr_db=psnr, delta_vs_full_db=psnr-full_psnr,
                                                    legacy_whole_psnr_db=legacy))
                        if not args.keep_images:
                            for mode in images:
                                Path(str(prefix) + '_0_' + mode + '.ppm').unlink()
                        print(tag, 'OK', flush=True)
                        # Checkpoint completed work; raw logs survive any later failure.
                        write_csv(args.out / 'quality.csv', quality)
        write_csv(args.out / 'timings.csv', times)
        groups = defaultdict(list)
        for q in quality:
            groups[(q['workload'], q['level'], q['timing'], q['mode'], q['region'])].append(q)
        summary = []
        for (workload, level, timing, mode, region), qs in sorted(groups.items()):
            ts = [t for t in times if (t['workload'], t['level'], t['timing'], t['mode']) == (workload, level, timing, mode)]
            bs = [t for t in times if (t['workload'], t['level'], t['timing'], t['mode']) == (workload, level, timing, 'full')]
            wall = [t['wall_ms'] for t in ts]
            summary.append(dict(workload=workload, level=level, timing=timing, mode=mode, region=region,
                                frames=len(set(q['frame'] for q in qs)), quality_samples=len(qs),
                                mean_standard_psnr_db=float(np.mean([q['standard_psnr_db'] for q in qs])),
                                mean_delta_vs_full_db=float(np.mean([q['delta_vs_full_db'] for q in qs])),
                                mean_legacy_whole_psnr_db=float(np.mean([q['legacy_whole_psnr_db'] for q in qs])),
                                wall_p50_ms=float(np.percentile(wall, 50)), wall_p95_ms=float(np.percentile(wall, 95)),
                                wall_p99_ms=float(np.percentile(wall, 99)),
                                gpu_p50_ms=float(np.percentile([t['gpu_timeline_ms'] for t in ts], 50)),
                                speedup_vs_full_p50=float(np.median([t['wall_ms'] for t in bs]) / np.median(wall))))
        write_csv(args.out / 'summary.csv', summary)
        (args.out / 'COMPLETE').write_text('All requested frames, levels and timings completed.\n')
    finally:
        if telemetry is not None:
            telemetry.terminate()
            telemetry.wait(timeout=10)
        if telemetry_file is not None:
            telemetry_file.close()


if __name__ == '__main__':
    main()
